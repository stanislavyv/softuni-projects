﻿namespace _02.DOM.Models
{
    using System;
    using System.Collections.Generic;
    using _02.DOM.Interfaces;

    public class HtmlElement : IHtmlElement
    {
        public HtmlElement(ElementType type, params IHtmlElement[] children)
        {
            this.Type = type;
            this.Children = new List<IHtmlElement>();
            this.Attributes = new Dictionary<string, string>();

            this.AddChildren(children);
        }

        public ElementType Type { get; set; }

        public IHtmlElement Parent { get; set; }

        public List<IHtmlElement> Children { get; }

        public Dictionary<string, string> Attributes { get; }

        public void AddChildren(params IHtmlElement[] children)
        {
            foreach (var child in children)
            {
                this.Children.Add(child);
                child.Parent = this;
            }
        }
        public void InsertFirst(IHtmlElement element)
        {
            this.Children.Insert(0, element);
            element.Parent = this;
        }
        public void InsertLast(IHtmlElement element)
        {
            this.Children.Add(element);
            element.Parent = this;
        }
    }
}
